create function anycompatiblearray_out(anycompatiblearray) returns cstring
    language internal
as
$$anycompatiblearray_out$$;

comment on function anycompatiblearray_out(anycompatiblearray) is 'I/O';

