create function binary_upgrade_create_empty_extension(text, text, boolean, text, oid[], text[], text[]) returns void
    language internal
as
$$binary_upgrade_create_empty_extension$$;

comment on function binary_upgrade_create_empty_extension(text, text, bool, text, _oid, _text, _text) is 'for use by pg_upgrade';

