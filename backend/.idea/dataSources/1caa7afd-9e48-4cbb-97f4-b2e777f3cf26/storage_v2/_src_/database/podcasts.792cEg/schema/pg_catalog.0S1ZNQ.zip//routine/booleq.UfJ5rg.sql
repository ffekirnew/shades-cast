create function booleq(boolean, boolean) returns boolean
    language internal
as
$$booleq$$;

comment on function booleq(bool, bool) is 'implementation of = operator';

