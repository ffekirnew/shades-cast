create function box_intersect(box, box) returns box
    language internal
as
$$box_intersect$$;

comment on function box_intersect(box, box) is 'implementation of # operator';

