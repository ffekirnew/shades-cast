create function btint4sortsupport(internal) returns void
    language internal
as
$$btint4sortsupport$$;

comment on function btint4sortsupport(internal) is 'sort support';

