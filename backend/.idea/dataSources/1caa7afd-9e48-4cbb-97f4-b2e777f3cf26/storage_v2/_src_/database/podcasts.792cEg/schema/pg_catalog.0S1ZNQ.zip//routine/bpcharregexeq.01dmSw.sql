create function bpcharregexeq(character, text) returns boolean
    language internal
as
$$textregexeq$$;

comment on function bpcharregexeq(bpchar, text) is 'implementation of ~ operator';

