create function "RI_FKey_restrict_upd"() returns trigger
    language internal
as
$$RI_FKey_restrict_upd$$;

comment on function "RI_FKey_restrict_upd"() is 'referential integrity ON UPDATE RESTRICT';

