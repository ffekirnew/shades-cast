create function bttext_pattern_cmp(text, text) returns integer
    language internal
as
$$bttext_pattern_cmp$$;

comment on function bttext_pattern_cmp(text, text) is 'less-equal-greater';

