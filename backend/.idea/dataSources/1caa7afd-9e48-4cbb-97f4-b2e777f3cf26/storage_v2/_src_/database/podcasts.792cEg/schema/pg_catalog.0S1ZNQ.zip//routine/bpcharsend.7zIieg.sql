create function bpcharsend(character) returns bytea
    language internal
as
$$bpcharsend$$;

comment on function bpcharsend(bpchar) is 'I/O';

