create function brin_summarize_range(regclass, bigint) returns integer
    language internal
as
$$brin_summarize_range$$;

comment on function brin_summarize_range(regclass, int8) is 'brin: standalone scan new table pages';

