create function bpcharicnlike(character, text) returns boolean
    language internal
as
$$texticnlike$$;

comment on function bpcharicnlike(bpchar, text) is 'implementation of !~~* operator';

