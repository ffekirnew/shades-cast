create function brin_minmax_multi_distance_date(internal, internal) returns double precision
    language internal
as
$$brin_minmax_multi_distance_date$$;

comment on function brin_minmax_multi_distance_date(internal, internal) is 'BRIN multi minmax date distance';

