create function btint48cmp(integer, bigint) returns integer
    language internal
as
$$btint48cmp$$;

comment on function btint48cmp(int4, int8) is 'less-equal-greater';

