create function "RI_FKey_noaction_upd"() returns trigger
    language internal
as
$$RI_FKey_noaction_upd$$;

comment on function "RI_FKey_noaction_upd"() is 'referential integrity ON UPDATE NO ACTION';

