create function anymultirange_out(anymultirange) returns cstring
    language internal
as
$$anymultirange_out$$;

comment on function anymultirange_out(anymultirange) is 'I/O';

