create function aclcontains(aclitem[], aclitem) returns boolean
    language internal
as
$$aclcontains$$;

comment on function aclcontains(_aclitem, aclitem) is 'contains';

