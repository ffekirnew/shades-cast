create function big5_to_utf8(integer, integer, cstring, internal, integer, boolean) returns integer
    cost 100
    language c
as
$$big5_to_utf8$$;

comment on function big5_to_utf8(int4, int4, cstring, internal, int4, bool) is 'internal conversion function for BIG5 to UTF8';

