create function bpcharle(character, character) returns boolean
    language internal
as
$$bpcharle$$;

comment on function bpcharle(bpchar, bpchar) is 'implementation of <= operator';

